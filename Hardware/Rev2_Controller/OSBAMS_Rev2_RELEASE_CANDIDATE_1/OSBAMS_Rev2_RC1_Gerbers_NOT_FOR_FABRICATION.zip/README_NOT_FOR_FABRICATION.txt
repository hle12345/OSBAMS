OSBAMS Rev.2 Controller RC1 - REVIEW CANDIDATE - NOT FOR FABRICATION.
These Gerber/drill files are a KiCad 10.0.6 export of a script-generated design. Regenerate them from the .kicad_pcb on your own KiCad installation,
re-run ERC/DRC, and clear every item in PCBWAY_RELEASE_CANDIDATE_REPORT.md (BLOCKERS BEFORE PCBWAY ORDER) before ordering.
